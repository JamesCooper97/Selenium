package com.QA.Shopping;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ShoppingTest {
	WebDriver driver = null;
	Actions builder = null;
	Index indexPage = null;
	
	
	@Before
	public void setup() {
		System.setProperty("webdriver.chrome.driver", "C:/Users/Admin/Desktop/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		builder = new Actions(driver);
		indexPage = PageFactory.initElements(driver, Index.class);
	}
	
	@Test
	public void test1() throws InterruptedException {
		driver.get("http://automationpractice.com/index.php");
		indexPage.hover(builder);
		//Thread.sleep(1000);
		indexPage.casualDressClick(builder, driver);
		
	}
	
	@After
	public void tearDown() throws InterruptedException {
		Thread.sleep(20000);
		driver.close();
	}
	
}
